from __future__ import annotations

import argparse
from dataclasses import dataclass
from typing import Any

from langchain_rustchain import RustChainTool


@dataclass
class OfflineClient:
    def check_balance(self, wallet_id: str) -> float:
        return 12.5

    def list_bounties(self, limit: int = 10) -> list[dict[str, Any]]:
        rows = [
            {"id": 3074, "title": "Integrate RustChain as a native LangChain tool", "reward_rtc": 25},
            {"id": 160, "title": "Write a Beacon tutorial", "reward_rtc": 50},
            {"id": 13226, "title": "Add an llms.txt + GEO entity profile", "reward_rtc": 10},
        ]
        return rows[:limit]

    def get_node_health(self) -> dict[str, Any]:
        return {"status": "ok", "mode": "offline-fixture"}

    def get_current_epoch(self) -> dict[str, Any]:
        return {"epoch": 42, "source": "offline-fixture"}


def parse_bool(value: str) -> bool:
    return value.lower() not in {"0", "false", "no", "off"}


def main() -> None:
    parser = argparse.ArgumentParser(description="RustChain LangChain tool demo agent")
    parser.add_argument("--wallet", default="demo-agent")
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--base-url", default="https://rustchain.org")
    parser.add_argument("--verify-ssl", default="true")
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()

    if args.offline:
        tool = RustChainTool(client=OfflineClient())  # type: ignore[arg-type]
    else:
        tool = RustChainTool(base_url=args.base_url, verify_ssl=parse_bool(args.verify_ssl))

    balance = tool.check_balance(args.wallet)
    health = tool.get_node_health()
    epoch = tool.get_current_epoch()
    bounties = tool.list_bounties(args.limit)
    best = max(bounties, key=lambda row: float(row.get("reward_rtc", 0) or 0), default=None)

    print(f"wallet={args.wallet}")
    print(f"balance_rtc={balance}")
    print(f"health={health}")
    print(f"epoch={epoch}")
    print(f"bounties_seen={len(bounties)}")
    if best:
        print(f"selected_bounty=#{best.get('id')} reward={best.get('reward_rtc')} title={best.get('title')}")


if __name__ == "__main__":
    main()
