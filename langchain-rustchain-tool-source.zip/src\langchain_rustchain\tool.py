from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import requests

try:
    from langchain_core.tools import BaseTool
except Exception:  # pragma: no cover - exercised when LangChain is absent
    class BaseTool:  # type: ignore[no-redef]
        name: str = ""
        description: str = ""

        def __init__(self, **kwargs: Any) -> None:
            for key, value in kwargs.items():
                setattr(self, key, value)


class RustChainAPIError(RuntimeError):
    """Raised when a RustChain HTTP API call fails or returns malformed data."""


@dataclass
class RustChainClient:
    base_url: str = "https://rustchain.org"
    timeout: float = 10.0
    verify_ssl: bool = True

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")

    def _get_json(self, path: str, params: dict[str, Any] | None = None) -> Any:
        url = f"{self.base_url}{path}"
        try:
            response = requests.get(
                url,
                params=params,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )
            response.raise_for_status()
            return response.json()
        except requests.RequestException as exc:
            raise RustChainAPIError(f"RustChain request failed for {path}: {exc}") from exc
        except ValueError as exc:
            raise RustChainAPIError(f"RustChain returned non-JSON data for {path}") from exc

    def check_balance(self, wallet_id: str) -> float:
        if not wallet_id.strip():
            raise ValueError("wallet_id is required")
        data = self._get_json("/wallet/balance", {"miner_id": wallet_id})
        for key in ("balance", "balance_rtc", "amount_rtc", "rtc"):
            value = data.get(key) if isinstance(data, dict) else None
            if value is not None:
                return float(value)
        raise RustChainAPIError("balance response did not include a known balance field")

    def list_bounties(self, limit: int = 10) -> list[dict[str, Any]]:
        if limit < 1:
            raise ValueError("limit must be >= 1")
        data = self._get_json("/agent/jobs", {"limit": limit})
        if isinstance(data, list):
            return [dict(item) for item in data[:limit] if isinstance(item, dict)]
        if isinstance(data, dict):
            for key in ("jobs", "bounties", "items", "data"):
                value = data.get(key)
                if isinstance(value, list):
                    return [dict(item) for item in value[:limit] if isinstance(item, dict)]
        raise RustChainAPIError("bounty response did not include a list")

    def get_node_health(self) -> dict[str, Any]:
        data = self._get_json("/health")
        if not isinstance(data, dict):
            raise RustChainAPIError("health response was not an object")
        return data

    def get_current_epoch(self) -> dict[str, Any]:
        data = self._get_json("/epoch")
        if not isinstance(data, dict):
            raise RustChainAPIError("epoch response was not an object")
        return data


class RustChainTool(BaseTool):
    name: str = "rustchain"
    description: str = (
        "Query RustChain wallet balances, live bounties, node health, and current epoch data."
    )

    def __init__(
        self,
        base_url: str = "https://rustchain.org",
        timeout: float = 10.0,
        verify_ssl: bool = True,
        client: RustChainClient | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.client = client or RustChainClient(
            base_url=base_url,
            timeout=timeout,
            verify_ssl=verify_ssl,
        )

    def _run(self, action: str, **kwargs: Any) -> Any:
        actions = {
            "check_balance": lambda: self.check_balance(str(kwargs["wallet_id"])),
            "list_bounties": lambda: self.list_bounties(int(kwargs.get("limit", 10))),
            "get_node_health": self.get_node_health,
            "get_current_epoch": self.get_current_epoch,
        }
        if action not in actions:
            raise ValueError(f"unsupported RustChain action: {action}")
        return actions[action]()

    def check_balance(self, wallet_id: str) -> float:
        return self.client.check_balance(wallet_id)

    def list_bounties(self, limit: int = 10) -> list[dict[str, Any]]:
        return self.client.list_bounties(limit)

    def get_node_health(self) -> dict[str, Any]:
        return self.client.get_node_health()

    def get_current_epoch(self) -> dict[str, Any]:
        return self.client.get_current_epoch()
