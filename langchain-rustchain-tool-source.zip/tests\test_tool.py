from __future__ import annotations

import pytest

from langchain_rustchain import RustChainAPIError, RustChainClient, RustChainTool


class FakeClient:
    def __init__(self, payloads):
        self.payloads = payloads

    def _get_json(self, path, params=None):
        return self.payloads[path]


def test_check_balance_accepts_known_balance_fields():
    client = RustChainClient()
    client._get_json = lambda path, params=None: {"amount_rtc": "7.25"}  # type: ignore[method-assign]

    assert client.check_balance("agent-wallet") == 7.25


def test_list_bounties_normalizes_wrapped_jobs():
    client = RustChainClient()
    client._get_json = lambda path, params=None: {"jobs": [{"id": 1}, {"id": 2}]}  # type: ignore[method-assign]

    assert client.list_bounties(limit=1) == [{"id": 1}]


def test_tool_dispatches_actions():
    class Stub:
        def check_balance(self, wallet_id):
            return 3.0

        def list_bounties(self, limit=10):
            return [{"id": 3074}]

        def get_node_health(self):
            return {"status": "ok"}

        def get_current_epoch(self):
            return {"epoch": 9}

    tool = RustChainTool(client=Stub())  # type: ignore[arg-type]

    assert tool._run("check_balance", wallet_id="wallet") == 3.0
    assert tool._run("list_bounties", limit=2) == [{"id": 3074}]
    assert tool._run("get_node_health") == {"status": "ok"}
    assert tool._run("get_current_epoch") == {"epoch": 9}


def test_invalid_shapes_raise_clear_errors():
    client = RustChainClient()
    client._get_json = lambda path, params=None: {"unexpected": True}  # type: ignore[method-assign]

    with pytest.raises(RustChainAPIError):
        client.check_balance("wallet")
    with pytest.raises(RustChainAPIError):
        client.list_bounties()
