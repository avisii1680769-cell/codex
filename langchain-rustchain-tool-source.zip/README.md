# LangChain RustChain Tool

Standalone LangChain-compatible RustChain tool package for bounty #3074.

This package exposes RustChain's public HTTP API as a small Python tool object
that can be used directly or wrapped by LangChain agents. It keeps the API
surface deliberately narrow:

- `check_balance(wallet_id: str) -> float`
- `list_bounties(limit: int = 10) -> list[dict]`
- `get_node_health() -> dict`
- `get_current_epoch() -> dict`

## Install

```bash
python -m pip install -e ".[dev]"
```

## Verify

```bash
python -m pytest
python examples/pick_bounty_agent.py --offline
```

## Offline Example

```bash
python examples/pick_bounty_agent.py --offline --wallet demo-agent --limit 3
```

The offline mode uses deterministic fixture data so reviewers can verify the
agent flow without depending on a live RustChain node.

## Live Example

```bash
python examples/pick_bounty_agent.py --wallet YOUR_WALLET --base-url https://rustchain.org
```

If your local environment needs to query the legacy node with a self-signed
certificate, pass `--verify-ssl false`.

## LangChain Usage

```python
from langchain_rustchain import RustChainTool

tool = RustChainTool(base_url="https://rustchain.org")
print(tool.check_balance("demo-agent"))
print(tool.list_bounties(limit=5))
print(tool.get_node_health())
print(tool.get_current_epoch())
```

The package includes a lightweight fallback base class so its tests and example
run even when LangChain is not installed. When `langchain_core` is available,
`RustChainTool` subclasses `langchain_core.tools.BaseTool`.
