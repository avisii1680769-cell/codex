# RustChain Attestation Data Export Pipeline

Export RustChain attestation and reward data to CSV, JSON, or JSONL for analytics and compliance workflows.

## Verify Before Trust

```bash
python -m pip install -e .
python -m pytest
rustchain-export --source api --format csv --output data/api-smoke
```

## Usage

API-only mode, works without direct database access:

```bash
rustchain-export --source api --node-url https://50.28.86.131 --format csv --output data/api
```

SQLite mode with date filtering:

```bash
rustchain-export --source sqlite --database rustchain.db --format jsonl --output data/export --from 2025-12-01 --to 2026-02-01
```

Supported formats:

- `csv`
- `json`
- `jsonl`

Exported datasets:

- `miners`
- `epochs`
- `rewards`
- `attestations`
- `balances`

Every run writes `export_summary.json` with row counts and output paths.

## API Mode Notes

The public node exposes summary endpoints, so API mode exports miners, current epoch, and balances. Reward and attestation history are emitted as empty datasets when the public API does not expose historical tables. SQLite mode exports all five datasets when the local database tables exist.

TLS verification defaults to disabled because the reference RustChain node has historically used self-signed certificates. Use `--verify-tls` for nodes with a valid certificate chain.
