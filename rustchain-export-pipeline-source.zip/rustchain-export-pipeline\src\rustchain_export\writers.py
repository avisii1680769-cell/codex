from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any


def write_dataset(dataset: dict[str, list[dict[str, Any]]], output: str, fmt: str) -> dict[str, dict[str, Any]]:
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    summary: dict[str, dict[str, Any]] = {}
    for name, rows in dataset.items():
        if fmt == "csv":
            path = out / f"{name}.csv"
            write_csv(path, rows)
        elif fmt == "json":
            path = out / f"{name}.json"
            path.write_text(json.dumps(rows, indent=2, sort_keys=True), encoding="utf-8")
        elif fmt == "jsonl":
            path = out / f"{name}.jsonl"
            path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows), encoding="utf-8")
        else:
            raise ValueError(f"Unsupported format: {fmt}")
        summary[name] = {"rows": len(rows), "path": str(path)}
    (out / "export_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    return summary


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = sorted({key for row in rows for key in row.keys()})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
