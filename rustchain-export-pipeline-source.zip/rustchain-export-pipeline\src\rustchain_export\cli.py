from __future__ import annotations

import argparse
import json
from typing import Any

from .sources import from_api, from_sqlite
from .writers import write_dataset


def run_export(
    *,
    source: str,
    output: str,
    fmt: str,
    database: str | None = None,
    node_url: str = "https://50.28.86.131",
    date_from: str | None = None,
    date_to: str | None = None,
    verify_tls: bool = False,
) -> dict[str, dict[str, Any]]:
    if source == "sqlite":
        if not database:
            raise ValueError("--database is required for sqlite source")
        dataset = from_sqlite(database, date_from, date_to)
    elif source == "api":
        dataset = from_api(node_url, verify_tls=verify_tls)
    else:
        raise ValueError(f"Unsupported source: {source}")
    return write_dataset(dataset.as_mapping(), output, fmt)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Export RustChain attestation and reward data.")
    parser.add_argument("--source", choices=["api", "sqlite"], default="api")
    parser.add_argument("--database", help="Path to local SQLite database for --source sqlite")
    parser.add_argument("--node-url", default="https://50.28.86.131")
    parser.add_argument("--format", choices=["csv", "json", "jsonl"], default="csv")
    parser.add_argument("--output", required=True)
    parser.add_argument("--from", dest="date_from", help="Inclusive start date, e.g. 2026-01-01")
    parser.add_argument("--to", dest="date_to", help="Inclusive end date, e.g. 2026-02-01")
    parser.add_argument("--verify-tls", action="store_true", help="Enable TLS certificate verification")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    summary = run_export(
        source=args.source,
        database=args.database,
        node_url=args.node_url,
        output=args.output,
        fmt=args.format,
        date_from=args.date_from,
        date_to=args.date_to,
        verify_tls=args.verify_tls,
    )
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
