from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from typing import Any

import requests


TABLES = ("miners", "epochs", "rewards", "attestations", "balances")


@dataclass
class ExportDataset:
    miners: list[dict[str, Any]]
    epochs: list[dict[str, Any]]
    rewards: list[dict[str, Any]]
    attestations: list[dict[str, Any]]
    balances: list[dict[str, Any]]

    def as_mapping(self) -> dict[str, list[dict[str, Any]]]:
        return {name: getattr(self, name) for name in TABLES}


def from_sqlite(database: str, date_from: str | None = None, date_to: str | None = None) -> ExportDataset:
    conn = sqlite3.connect(database)
    conn.row_factory = sqlite3.Row
    try:
        return ExportDataset(
            miners=query_table(conn, "miners", "last_attestation", date_from, date_to),
            epochs=query_table(conn, "epoch_state", "timestamp", date_from, date_to, alias="epochs"),
            rewards=query_table(conn, "epoch_rewards", "timestamp", date_from, date_to),
            attestations=query_table(conn, "miner_attest_recent", "timestamp", date_from, date_to, alias="attestations"),
            balances=query_table(conn, "balances", None, date_from, date_to),
        )
    finally:
        conn.close()


def query_table(
    conn: sqlite3.Connection,
    table: str,
    date_column: str | None,
    date_from: str | None,
    date_to: str | None,
    alias: str | None = None,
) -> list[dict[str, Any]]:
    if not table_exists(conn, table):
        return []
    sql = f"SELECT * FROM {table}"
    params: list[str] = []
    clauses: list[str] = []
    if date_column and column_exists(conn, table, date_column):
        if date_from:
            clauses.append(f"{date_column} >= ?")
            params.append(date_from)
        if date_to:
            clauses.append(f"{date_column} <= ?")
            params.append(date_to)
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    rows = [dict(row) for row in conn.execute(sql, params)]
    if alias == "epochs":
        return [normalize_epoch(row) for row in rows]
    if alias == "attestations":
        return [normalize_attestation(row) for row in rows]
    return rows


def table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
    return row is not None


def column_exists(conn: sqlite3.Connection, table: str, column: str) -> bool:
    return any(row[1] == column for row in conn.execute(f"PRAGMA table_info({table})"))


def normalize_epoch(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "epoch": row.get("epoch") or row.get("epoch_number"),
        "timestamp": row.get("timestamp"),
        "pot_size": row.get("pot_size") or row.get("pot"),
        "settlement_status": row.get("settlement_status") or row.get("status"),
    }


def normalize_attestation(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "miner_id": row.get("miner_id"),
        "timestamp": row.get("timestamp"),
        "device_info": row.get("device_info") or row.get("hardware") or row.get("architecture"),
    }


def from_api(node_url: str, timeout: float = 20.0, verify_tls: bool = False) -> ExportDataset:
    base = node_url.rstrip("/")
    session = requests.Session()

    def get(path: str) -> Any:
        response = session.get(f"{base}{path}", timeout=timeout, verify=verify_tls)
        response.raise_for_status()
        return response.json()

    miners_raw = get("/api/miners")
    miners = miners_raw.get("miners", miners_raw if isinstance(miners_raw, list) else [])
    epoch_raw = get("/epoch")
    epochs = [epoch_raw] if isinstance(epoch_raw, dict) else []
    balances = []
    for miner in miners:
        miner_id = miner.get("miner_id") or miner.get("miner") or miner.get("id") or miner.get("wallet_id")
        if not miner_id:
            continue
        try:
            balance = get(f"/wallet/balance?miner_id={miner_id}")
            balances.append({"wallet_id": miner_id, **(balance if isinstance(balance, dict) else {"balance": balance})})
        except requests.RequestException:
            balances.append({"wallet_id": miner_id, "balance_error": True})
    return ExportDataset(miners=list(miners), epochs=epochs, rewards=[], attestations=[], balances=balances)
