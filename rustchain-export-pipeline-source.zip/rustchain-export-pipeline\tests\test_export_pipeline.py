from __future__ import annotations

import csv
import json
import sqlite3
from pathlib import Path

from rustchain_export.cli import run_export


def make_db(path: Path) -> None:
    conn = sqlite3.connect(path)
    conn.executescript(
        """
        CREATE TABLE miners (
          miner_id TEXT, architecture TEXT, last_attestation TEXT, total_earnings REAL
        );
        CREATE TABLE epoch_state (
          epoch INTEGER, timestamp TEXT, pot_size REAL, settlement_status TEXT
        );
        CREATE TABLE epoch_rewards (
          epoch INTEGER, miner_id TEXT, reward_amount REAL, timestamp TEXT
        );
        CREATE TABLE miner_attest_recent (
          miner_id TEXT, timestamp TEXT, device_info TEXT
        );
        CREATE TABLE balances (
          wallet_id TEXT, balance REAL
        );
        """
    )
    conn.executemany("INSERT INTO miners VALUES (?, ?, ?, ?)", [
        ("miner-a", "PowerPC G4", "2026-01-02T00:00:00Z", 12.5),
        ("miner-b", "x86_64", "2026-03-02T00:00:00Z", 2.0),
    ])
    conn.executemany("INSERT INTO epoch_state VALUES (?, ?, ?, ?)", [
        (1, "2026-01-03T00:00:00Z", 10.0, "settled"),
        (2, "2026-03-03T00:00:00Z", 10.0, "pending"),
    ])
    conn.execute("INSERT INTO epoch_rewards VALUES (1, 'miner-a', 1.25, '2026-01-03T00:00:00Z')")
    conn.execute("INSERT INTO miner_attest_recent VALUES ('miner-a', '2026-01-02T00:00:00Z', 'g4')")
    conn.execute("INSERT INTO balances VALUES ('miner-a', 12.5)")
    conn.commit()
    conn.close()


def test_sqlite_csv_export_with_date_filter(tmp_path: Path) -> None:
    db = tmp_path / "rustchain.db"
    out = tmp_path / "out"
    make_db(db)

    summary = run_export(source="sqlite", database=str(db), output=str(out), fmt="csv", date_from="2026-01-01", date_to="2026-02-01")

    assert summary["miners"]["rows"] == 1
    assert summary["epochs"]["rows"] == 1
    with (out / "miners.csv").open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert rows[0]["miner_id"] == "miner-a"
    assert (out / "export_summary.json").exists()


def test_jsonl_export_writes_one_record_per_line(tmp_path: Path) -> None:
    db = tmp_path / "rustchain.db"
    out = tmp_path / "out"
    make_db(db)

    run_export(source="sqlite", database=str(db), output=str(out), fmt="jsonl")

    lines = (out / "balances.jsonl").read_text(encoding="utf-8").strip().splitlines()
    assert json.loads(lines[0]) == {"wallet_id": "miner-a", "balance": 12.5}
